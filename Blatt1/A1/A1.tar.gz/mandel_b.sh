#!/bin/bash
gcc -o mandel mandel.c
./mandel 1200 800 > output.bmp